declare module 'swagger-jsdoc' {
  /** Minimal declaration for swagger-jsdoc */
  function swaggerJSDoc(options?: any): any;
  namespace swaggerJSDoc {}
  export = swaggerJSDoc;
}
